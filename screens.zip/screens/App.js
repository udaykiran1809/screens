/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
// import type {Node} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';

import {
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

import SignInScreen from './scr/screens/SigninScreen/SignInScreen';
import SignUpScreen from './scr/screens/SigninScreen/SignUpScreen';
import Splash from './scr/screens/SigninScreen/splash/Splash';
import Intro_1 from './scr/screens/SigninScreen/intro_1/Intro_1';
import Intro_2 from './scr/screens/SigninScreen/intro_2/Intro_2';
import Drawer from './scr/screens/drawer/Drawer';
import Settings from './scr/screens/settings';

function App(){
  // const isDarkMode = useColorScheme() === 'dark';

  // const backgroundStyle = {
  //   backgroundColor: isDarkMode ? Colors.darker : Colors.lighter,
  // };

  return (
    <SafeAreaView style={styles.root}>
      
      {/* <SignInScreen /> */}
      {/* <SignUpScreen/> */}
      {/* <Splash/> */}
      <Intro_2/>
      {/* <Drawer /> */}
      {/* <Settings/> */}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  root:{
    flex: 1,
  }
});

export default App;
