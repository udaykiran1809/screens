import { StyleSheet, Text, View, TouchableOpacity,Image } from 'react-native'
import React from 'react'
// import Icon from 'react-native-vector-icons';

export default function Drawer() {
  return (
    <View style = {styles.container}>
      <Image 
        source={require('../drawer/images/img.png')}
        style = {styles.starting_image_style}
      />
      <Text style={styles.text_nus}>Name</Text>
      <Text style={styles.text_nus}>UserID</Text>
      <View style = {styles.container_1}> 
        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/Home.png')}/>
          <Text style={styles.text_style}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/sub.png')}/>
          <Text style={styles.text_style}>Subscribed Plan</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/History.png')}/>
          <Text style={styles.text_style}>History</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/mail.png')}/>
          <Text style={styles.text_style}>Invite Friends</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/set.png')}/>
          <Text style={styles.text_style}>Settings</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/sup.png')}/>
          <Text style={styles.text_style}>Online Support</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.image_text_align}>
          <Image source={require('../drawer/images/logout.png')}/>
          <Text style={styles.text_style}>Log out</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor: '#007AFF',
        // alignItems: 'start',
        paddingHorizontal: 20,
        alignContent: 'center',
        // paddingVertical: '60%'
        // alignItems:'center'
    },
    container_1:{
      flex:1.65,
      backgroundColor: '#007AFF',
      // alignItems: 'start',
      paddingHorizontal: 20,
      alignContent: 'center',
      paddingVertical: '30%'
      // alignItems:'center'
  },
    
    image_text_align:{
      flexDirection: 'row',
      paddingBottom: '7%'
    },

    text_style:{
      color: '#FFFFFF',
      paddingHorizontal: '1.5%',
      fontSize: 15
    },

    starting_image_style:{
      // paddingHorizontal: '30%',
      height: '20%',
      width: '41%',
    },
    text_nus:{
      color: '#FFFF',
      alignItems: 'center',
      fontSize: 20
    }
})
