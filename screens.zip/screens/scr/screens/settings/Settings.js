import { 
    View, 
    Text,
    StyleSheet, 
    TouchableOpacity,
    Image
} from 'react-native'
import React from 'react'

export default function Settings() {
  return (
    <View style = {styles.container}>
      {/* <TouchableOpacity style = {styles.icon_style}>
          <Image
            source={require('../settings/images/left-arrow.png')}
          />  
        </TouchableOpacity> */}
      <Image
            source={require('../settings/images/left-arrow.png')}
        /> 
      <Text style={styles.text_style}>Settings</Text>

      <Image
            source={require('../settings/images/Notification.png')}
        /> 
      <View style = {styles.bottomView}>
          
          <TouchableOpacity style = {styles.button_style}>
              <Text style = {styles.button_text_style}>Phone Number</Text>
          </TouchableOpacity>

          <TouchableOpacity style = {styles.button_style}>
              <Text style = {styles.button_text_style}>Call</Text>
          </TouchableOpacity>

          <TouchableOpacity style = {styles.button_style}>
              <Text style = {styles.button_text_style}>Notification</Text>
          </TouchableOpacity>

          <TouchableOpacity style = {styles.button_style}>
              <Text style = {styles.button_text_style}>Favorite Address</Text>
          </TouchableOpacity>

          <TouchableOpacity style = {styles.button_style}>
              <Text style = {styles.button_text_style}>Language</Text>
          </TouchableOpacity>

      </View>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        // flexDirection: 'row',
        flex:1,
        backgroundColor: '#007AFF'
    },

    bottomView:{
        position: 'absolute',
        justifyContent:'center',
        height: '85%',
        width: '100%',
        alignItems: 'center',
        backgroundColor: 'white',
        // margin: 12,
        bottom: 0,
        borderTopStartRadius: 20,
        borderTopEndRadius: 20,
    },

    button_style:{
        width: '90%',
        margin: 12,
        borderColor: '#000',
        padding: 10,
        color: '#000',
        backgroundColor:'#F9FAFF',
        // justifyContent: 'center',
        alignItems : 'center'
    },

    button_text_style:{
        color: '#007AFF'
    },

    icon_style:{
        backgroundColor: '#007AFF'
    },

    text_style:{
        color: '#FFFFFF'
    }

})
