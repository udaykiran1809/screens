import {
    StyleSheet, 
    Text, 
    View, 
    Image,
    TouchableOpacity 
} from 'react-native'
import React from 'react'
import { NavigationContainer } from '@react-navigation/native';

export default function Intro_1() {
  return (
    <View style = {styles.container}>
        <Text style={styles.text_style_container}>Skip</Text>
        <Image
            source={require('../images/Frame1.png')}
            style = {styles.image_style}
        />
        <View style = {styles.bottomView}>
            <Text style={styles.title_text}>Confirm Your Ride</Text>
            <Text style={styles.text_style}>Huge delivery network. Helps you find comforable, safe and cheap ride.</Text>
            <TouchableOpacity
                style = {styles.button_style}
                // onPress ={() => navigation.toggleDrawer()}
            >
                <Text style = {styles.button_text_style}>Next</Text>
            </TouchableOpacity>
        </View>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor: '#FFFF'
    },
    
    text_style_container:{
        color:'#007AFF',
        alignContent: 'flex-end',
        justifyContent: 'flex-end',
        paddingLeft: '90%',
        paddingBottom: '5%'
    },

    bottomView:{
        flex: 1,
        position: 'absolute',
        // justifyContent:'center',
        height: '30%',
        width: '100%',
        alignItems: 'center',
        backgroundColor: '#007AFF',
        // margin: 12,
        bottom: 0,
        borderTopStartRadius: 20,
        borderTopEndRadius: 20,
    },

    image_style:{
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        height: '50%',
        width: '90%',
        // paddingBottom: '30%'
    },

    title_text:{
        color: '#FFFF',
        fontSize: 25,
        padding: 10
    },

    text_style:{
        fontSize: 18,
        color: '#FFFF',
        justifyContent: 'center',
        alignContent: 'center'
    },

    button_style:{
        width: '25%',
        margin: 12,
        padding: 10,
        color: '#007AFF',
        backgroundColor:'#FFFF',
        // justifyContent: 'center',
        alignItems : 'center'
    },
    button_text_style:{
        color: '#007AFF'
    }

})