import { 
    View, 
    Text,
    StyleSheet,
    Image, 
} from 'react-native'
import React from 'react'
import LinearGradient from 'react-native-linear-gradient'

export default function Splash() {
  return (
    <LinearGradient colors={['#590CBB','#007AFF','#0CA9BE']} style={style.linearGradient}>
        {/* <Text>HEllo world</Text> */}
        <Image
          style={{ width: 150, height: 150}}
          source={require('../images/sah-bike.png')}
        />
        <Text style={style.title_style}>SAHRUDAYA</Text>
        <Text style={style.text_style}>Step towards Unity</Text>
    </LinearGradient>
    // <View>
    //   <Text>Hello world</Text>
    //   <Image
    //     source={require('../images/sah-bike.png')}
    //   />
    // </View>
  )
}

const style = StyleSheet.create({
    linearGradient:{
        flex:1,
        alignItems:'center',
        justifyContent: 'center'
    },

    title_style:{
      fontFamily: 'Righteous',
      fontSize: 30,
      color: '#FFFF',
      fontWeight: 'bold'
    },
    
    text_style:{
      fontSize: 18,
      color:'#FFFFF'
    }

    
});