import { 
    View,
    Text,
    ScrollView,
    StyleSheet, 
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    Image
} from 'react-native'
import React from 'react'
// import googleIcon from './images'

export default function SignUpScreen() {
  return (
    <ScrollView contentContainerStyle = {{flex:1}} bounces ={true}>
       
        <View style = {styles.container}>
            <Text style = {styles.titleText}>Create your account</Text>
            <Text style = {styles.baseText}>UserID</Text>
            <TextInput
                style = {styles.input}
                placeholder = 'ex: abc@xyz.com'
                keyboardType= 'email-address'
            />
            <Text style = {styles.baseText}>Password</Text>
            <TextInput 
                style = {styles.input}
                // onChangeText = {onChangeText}
                placeholder = 'Enter your password'
                keyboardType = 'default'
                secureTextEntry = {true}
                // inlineImageRight = 'search_icon'
            />
            <TextInput 
                style = {styles.input}
                // onChangeText = {onChangeText}
                placeholder = 'Confirm your password'
                keyboardType = 'default'
                secureTextEntry = {true}
                // inlineImageRight = 'search_icon'
            />
            <Text style = {styles.baseText}>Phone Number</Text>
            <TextInput
                style = {styles.input}
                placeholder = 'Ex: 654XXXX56X'
                keyboardType= 'name-phone-pad'
            />
            <TouchableOpacity
                style = {styles.button_style}
                
            >
                <Text style = {styles.button_text_style}>Sign up</Text>
            </TouchableOpacity>
            {/* <Text style= {styles.or_text}>Or</Text> */}
            
            
            <View style = {styles.bottomView}>
              <Text style = {styles.bottom_text}>Already have an account?</Text>
              <TouchableOpacity
                style = {styles.bottom_button_style}
                
              >
                <Text style = {styles.bottom_text}>Sign In</Text>
              </TouchableOpacity>
           </View>
        </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#007AFF',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    // fontSize: 50,
  },

  baseText: {
    color: '#E5E5E5',
    padding: 20,
    fontSize: 20,

  },
  
  titleText: {
    fontSize: 35,
    // fontWeight: 'bold',
    fontFamily: "Roboto",
    color: '#E5E5E5',
    padding: 20
  },
  
  input: {
    height: 50,
    width: "90%",
    margin: 12,
    borderWidth: 1,
    // padding: 10,
    color: '#E5E5E5',
    borderColor: '#E5E5E5'
  },
  
  button_style: {
    width: '90%',
    margin: 12,
    padding: 10,
    color: '#E5E5E5',
    backgroundColor:'#FFFF',
    // justifyContent: 'center',
    alignItems : 'center'
  },

  button_text_style: {
    color: '#007AFF',
  },

  bottomView:{
    position: 'absolute',
    justifyContent:'center',
    height: '15%',
    width: '100%',
    alignItems: 'center',
    backgroundColor: 'white',
    // margin: 12,
    bottom: 0,
    borderTopStartRadius: 20,
    borderTopEndRadius: 20,
  },

  bottom_text: {
    color: '#7177AB'
  },

  bottom_button_style:{
    width: '90%',
    margin: 12,
    borderColor: '#000',
    padding: 10,
    color: '#000',
    backgroundColor:'#F9FAFF',
    // justifyContent: 'center',
    alignItems : 'center'
  },

  or_text:{
    color: '#F9FAFF',
    fontSize: 20,
    alignSelf: 'center',
  },

});